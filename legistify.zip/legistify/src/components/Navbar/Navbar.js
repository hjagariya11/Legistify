import React from "react";
import { useSelector, useDispatch } from "react-redux";

export default function Navbar() {
  const lang = useSelector(state => state.lang);
  const dispatch = useDispatch();
 

  return (
    <>
      <nav className="navbar navbar-dark bg-dark">
        <a className="navbar-brand">{"LAW FIRMS"}</a>
        <div className="d-flex align-items-center">
        </div>
      </nav>
    </>
  );
}
